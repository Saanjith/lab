from flask import Flask,render_template,request
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing import image
import pickle
import numpy as np

model= pickle.load(open('cnnmnist.pkl','rb'))

app=Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/predict',methods=['post'])
def predict():
    img=request.files['image']
    imgpath="static/"+img.filename
    print(imgpath)
    img.save(imgpath)
    i=image.load_img(imgpath,target_size=(28,28))
    i=i.convert("L")
    plt.imshow(i)
    i=image.img_to_array(i)/255.0
    print("i.shape:",i.shape)
    i=i.reshape(1,28,28,1)
    print('i:',i)
    p=model.predict(i)
    print('p',p)
    res=np.argmax(p)
    print('res',res)
    return render_template('success.html',data=res)

if __name__=='__main__':
    app.run()